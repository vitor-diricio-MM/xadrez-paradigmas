module Gui (iniciarJogo) where

import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import Tabuleiro (Tabuleiro, tabuleiroInicial, Peca(..), Cor(..))
import Utils (charToPeca)

-- Define o tamanho da janela e do tabuleiro
larguraJanela, alturaJanela, offset :: Int
larguraJanela = 600
alturaJanela = 600
offset = 100

-- Define o estado inicial do jogo
estadoInicial :: (Tabuleiro, Cor)
estadoInicial = (tabuleiroInicial, Branca)

-- Função para iniciar o jogo
iniciarJogo :: IO ()
iniciarJogo = play
  (InWindow "Jogo de Xadrez" (larguraJanela, alturaJanela) (offset, offset))
  white
  30
  estadoInicial
  desenharEstado
  tratarEvento
  atualizarEstado

-- Função para desenhar o estado do jogo
desenharEstado :: (Tabuleiro, Cor) -> Picture
desenharEstado (tab, _) = Pictures $ concatMap desenharLinha (zip [0..] tab)

-- Função para desenhar uma linha do tabuleiro
desenharLinha :: (Int, [Char]) -> [Picture]
desenharLinha (y, linha) = map (desenharPeca y) (zip [0..] linha)

-- Função para desenhar uma peça
desenharPeca :: Int -> (Int, Char) -> Picture
desenharPeca y (x, pecaChar) =
  let peca = charToPeca pecaChar
      cor = if even (x + y) then light blue else light yellow
  in Translate (fromIntegral x * 75 - 300) (fromIntegral y * 75 - 300) $
     Pictures [Color cor (rectangleSolid 75 75), desenharPecaChar peca]

-- Função para desenhar o caractere da peça
desenharPecaChar :: Peca -> Picture
desenharPecaChar peca = Color black $ Scale 0.3 0.3 $ Text (show peca)

-- Função para tratar eventos (a ser implementada)
tratarEvento :: Event -> (Tabuleiro, Cor) -> (Tabuleiro, Cor)
tratarEvento _ estado = estado

-- Função para atualizar o estado do jogo (a ser implementada)
atualizarEstado :: Float -> (Tabuleiro, Cor) -> (Tabuleiro, Cor)
atualizarEstado _ estado = estado