-- AI.hs

module AI (getBestMove) where

import CheckMate (movimentoValido)
import Data.Maybe (mapMaybe)
import System.Random (randomRIO)
import Tabuleiro (Cor (..), Posicao, Tabuleiro, pecaNaPosicao)
import Utils (charToPeca, corPeca)

-- | Obtém o melhor movimento para a AI (Pretas) de forma aleatória entre os movimentos válidos
getBestMove :: Tabuleiro -> IO (Maybe (Posicao, Posicao))
getBestMove tab = do
  let corAI = Preta
  let todosMovimentos = obterTodosMovimentos tab corAI
  if null todosMovimentos
    then return Nothing -- Sem movimentos disponíveis
    else do
      idx <- randomRIO (0, length todosMovimentos - 1)
      return $ Just (todosMovimentos !! idx)

-- | Obtém todos os movimentos válidos para uma determinada cor
obterTodosMovimentos :: Tabuleiro -> Cor -> [Posicao, Posicao] -> [Posicao -> Posicao -> Maybe (Posicao, Posicao)]
obterTodosMovimentos tab cor =
  let linhas = zip [0 ..] tab
   in concatMap (obterMovimentosParaLinha cor tab) linhas

-- | Obtém movimentos válidos para uma linha específica
obterMovimentosParaLinha :: Cor -> Tabuleiro -> (Int, [Char]) -> [Posicao -> Posicao -> Maybe (Posicao, Posicao)]
obterMovimentosParaLinha cor tab (y, linha) =
  mapMaybe (movimentoValidoAI cor tab y) (zip [0 ..] linha)

-- | Verifica se uma peça na posição (x, y) pertence à AI e retorna uma função de movimento válida
movimentoValidoAI :: Cor -> Tabuleiro -> Int -> (Int, Char) -> Maybe (Posicao, Posicao)
movimentoValidoAI cor tab y (x, pecaChar) =
  let peca = charToPeca pecaChar
   in case peca of
        Just p ->
          if corPeca p == cor
            then
              let orig = (x, y)
                  movimentos = movimentoValido tab orig
               in case movimentos of
                    [] -> Nothing
                    _ -> Just orig -- Aqui retornamos apenas a posição de origem; a AI escolherá depois
            else Nothing
        Nothing -> Nothing