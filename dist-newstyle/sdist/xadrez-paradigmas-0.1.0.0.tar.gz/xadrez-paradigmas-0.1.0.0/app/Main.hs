import Gui (iniciarJogo)

main :: IO ()
main = iniciarJogo